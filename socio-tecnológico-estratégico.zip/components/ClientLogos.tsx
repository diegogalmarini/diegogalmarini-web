import React, { useState, useEffect, ElementType } from 'react';

interface Logo {
  name: string;
  icon: ElementType;
}

interface ClientLogosProps {
  logos: Logo[];
}

// A more robust LogoItem component for better visual balance
const LogoItem: React.FC<{ logo: Logo }> = ({ logo }) => (
  <div
    className="group flex h-[70px] items-center justify-center p-2"
    aria-label={logo.name}
  >
    <logo.icon className="h-auto w-auto max-h-[70px] max-w-[200px] object-contain text-[var(--text-color)] opacity-60 transition-all duration-300 group-hover:opacity-100 group-hover:scale-105" />
  </div>
);

export const ClientLogos: React.FC<ClientLogosProps> = ({ logos }) => {
  const [displayedLogos, setDisplayedLogos] = useState<Logo[]>([]);

  // Effect to select a random subset of 7 logos on component mount
  useEffect(() => {
    const shuffled = [...logos].sort(() => 0.5 - Math.random());
    setDisplayedLogos(shuffled.slice(0, 7));
  }, [logos]);

  // Don't render if we don't have enough logos for the layout
  if (displayedLogos.length < 7) {
    return null;
  }

  const topRowLogos = displayedLogos.slice(0, 3);
  const bottomRowLogos = displayedLogos.slice(3, 7);

  return (
    // Reduced vertical spacing for a more compact appearance
    <div className="space-y-4">
      {/* Top row with 3 logos */}
      <div className="grid grid-cols-3 items-center justify-items-center gap-x-8 md:gap-x-12">
        {topRowLogos.map((logo) => (
          <LogoItem key={logo.name} logo={logo} />
        ))}
      </div>
      {/* Bottom row with 4 logos */}
      <div className="grid grid-cols-4 items-center justify-items-center gap-x-8 md:gap-x-12">
        {bottomRowLogos.map((logo) => (
          <LogoItem key={logo.name} logo={logo} />
        ))}
      </div>
    </div>
  );
};
