// This page is no longer in use and its content has been moved to LoginModal.tsx
import React from 'react';

const LoginPage: React.FC = () => {
  return null;
};

export default LoginPage;
